# ☕ SpiceBus — AOS Multi-Agent Communication Bus

> **3 Active AI Agents + 1 Human Director + 1 Neutral Monitor**
> *"Minimum In, Maximum Out — That's AOS Communication!"*

---

## 🏗️ Architecture

```
         🦅 DIRECTOR (Mamoun)
              │ assigns tasks, reads alerts
    ┌─────────┼─────────┐
    ▼         ▼         ▼
  🐻 AI₁   🤖 AI₂   🆕 AI₃        ← AGENTS
  (Claude)  (Wonder) (Stagiaire)     claim, work, deliver
              │
         ┌────┘ all messages flow through SpiceBus
         ▼
      👁️ AI₄ (Neutral Monitor)      ← reads ALL, writes NOTHING
         │                              except ALERTS → Director
         └→ ⚠️ ALERTS
```

## 🚀 Quick Start

### 1. Initialize (first time)
```bash
python spicebus.py init
```
This creates the database and Director token.

### 2. Start the bus
```bash
python spicebus.py serve        # default port 5555
python spicebus.py serve 8888   # custom port
```

### 3. Register agents (as Director)
```bash
aos-bus register Claude agent
aos-bus register Wonder agent
aos-bus register Stagiaire agent
aos-bus register Guardian monitor
```

### 4. Configure CLI per agent
```bash
# On Claude's machine:
aos-bus config aos-claude http://localhost:5555

# On Wonder's machine:
aos-bus config aos-wonder http://host:5555
```

### 5. Workflow

```bash
# DIRECTOR posts a task
aos-bus task "Build WinAOS installer" --to aos-wonder

# AGENT claims it
aos-bus claim abc123

# AGENT delivers
aos-bus deliver abc123 "WinAOS.exe ready at /builds/winaos.exe"

# MONITOR checks everything
aos-bus status
aos-bus audit --limit 50

# MONITOR raises alert
aos-bus alert "Wonder hasn't delivered in 48h!"

# DIRECTOR reads alerts
aos-bus alerts
```

## 📡 API Endpoints

| Method | Endpoint | Who | Description |
|--------|----------|-----|-------------|
| GET | `/api/health` | Anyone | Health check |
| POST | `/api/agents` | Director | Register agent |
| GET | `/api/agents` | All | List agents |
| POST | `/api/work` | Director | Post task |
| GET | `/api/work` | All | Get tasks |
| POST | `/api/work/<id>/claim` | Agent | Claim task |
| POST | `/api/work/<id>/deliver` | Agent | Deliver work |
| GET | `/api/monitor/audit` | Monitor/Director | Audit log |
| GET | `/api/monitor/status` | Monitor/Director | System status |
| POST | `/api/alerts` | Monitor | Post alert |
| GET | `/api/alerts` | Director | Read alerts |
| POST | `/api/message` | All | Inter-agent message |

## 🔐 Security

- **Token-based auth** — each agent has a unique token
- **Role-based access** — Director, Agent, Monitor
- **Full audit trail** — every action logged
- **Monitor isolation** — can READ all, WRITE only alerts

## 🔧 Requirements

- Python 3.10+
- Flask
- SQLite3 (built-in)
- requests (for CLI client)

## 📁 Files

```
~/.spicebus/
├── spicebus.db    ← SQLite database
├── tokens.json    ← Agent tokens (Director keeps this safe)
└── client.json    ← CLI client config (per machine)
```

---

*SpiceBus ☕ — Part of the AOS Ecosystem*
*🐻 + 🤖 = Coherence INSIDE Harmony*
*🟩⬜⬛*
