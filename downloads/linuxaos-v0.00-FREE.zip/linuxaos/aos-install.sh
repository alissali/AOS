#!/bin/bash
###############################################################################
#
#   LinuxAOS — Adequate Operating System — Installer v0.00 FREE
#   "Try Me You'll Love Me!"
#
#   Transforms any Ubuntu 22.04/24.04 into LinuxAOS
#   Usage: sudo bash aos-install.sh
#
#   ⚠️  Run from the linuxaos/ directory (where branding assets live)
#
#   JuXITT — The Meeting Point
#   © Mamoun Alissali — 2026
#
###############################################################################

set -e

# ═══════════════════════════════════════════════════════════════════════════
# COLORS & BRANDING
# ═══════════════════════════════════════════════════════════════════════════
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m'

AOS_VERSION="0.00-FREE"
if [ -n "$SUDO_USER" ]; then
    AOS_HOME="$(getent passwd "$SUDO_USER" | cut -d: -f6)/aos"
else
    AOS_HOME="$HOME/aos"
fi

banner() {
    echo -e "${CYAN}"
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║                                                            ║"
    echo "║   ██╗     ██╗███╗   ██╗██╗   ██╗██╗  ██╗ █████╗  ██████╗  ║"
    echo "║   ██║     ██║████╗  ██║██║   ██║╚██╗██╔╝██╔══██╗██╔═══██╗ ║"
    echo "║   ██║     ██║██╔██╗ ██║██║   ██║ ╚███╔╝ ███████║██║   ██║ ║"
    echo "║   ██║     ██║██║╚██╗██║██║   ██║ ██╔██╗ ██╔══██║██║   ██║ ║"
    echo "║   ███████╗██║██║ ╚████║╚██████╔╝██╔╝ ██╗██║  ██║╚██████╔╝ ║"
    echo "║   ╚══════╝╚═╝╚═╝  ╚═══╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝  ║"
    echo "║                                                            ║"
    echo "║          Adequate Operating System v${AOS_VERSION}                    ║"
    echo "║          \"Try Me You'll Love Me!\"                          ║"
    echo "║                                                            ║"
    echo "║          JuXITT — The Meeting Point                        ║"
    echo "║                                                            ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

step() {
    echo -e "\n${GREEN}[AOS]${NC} ${BOLD}$1${NC}"
}

info() {
    echo -e "  ${BLUE}→${NC} $1"
}

warn() {
    echo -e "  ${YELLOW}⚠${NC} $1"
}

success() {
    echo -e "  ${GREEN}✓${NC} $1"
}

fail() {
    echo -e "  ${RED}✗${NC} $1"
    exit 1
}

# ═══════════════════════════════════════════════════════════════════════════
# PRE-CHECKS
# ═══════════════════════════════════════════════════════════════════════════
preflight() {
    step "Pre-flight checks..."

    # Root check
    if [ "$EUID" -ne 0 ]; then
        fail "Please run as root: sudo bash aos-install.sh"
    fi

    # Ubuntu check
    if ! grep -qi "ubuntu" /etc/os-release 2>/dev/null; then
        fail "LinuxAOS requires Ubuntu 22.04 or 24.04 as base"
    fi

    # Version check
    VERSION=$(grep VERSION_ID /etc/os-release | cut -d'"' -f2)
    if [[ "$VERSION" != "22.04" && "$VERSION" != "24.04" ]]; then
        warn "Ubuntu $VERSION detected. Recommended: 22.04 or 24.04"
        read -p "  Continue anyway? (y/n) " -n 1 -r
        echo
        [[ ! $REPLY =~ ^[Yy]$ ]] && exit 1
    fi

    # RAM check
    RAM_MB=$(free -m | awk '/Mem:/{print $2}')
    info "RAM detected: ${RAM_MB}MB"
    if [ "$RAM_MB" -lt 3500 ]; then
        warn "Less than 4GB RAM — AI Layer will use small models only"
    fi

    # Disk check
    DISK_FREE=$(df -BG / | awk 'NR==2{print $4}' | tr -d 'G')
    info "Free disk space: ${DISK_FREE}GB"
    if [ "$DISK_FREE" -lt 20 ]; then
        fail "Need at least 20GB free disk space"
    fi

    # Internet check
    if ! ping -c 1 -W 3 8.8.8.8 &>/dev/null; then
        fail "No internet connection detected"
    fi

    success "All pre-flight checks passed"
}

# ═══════════════════════════════════════════════════════════════════════════
# LAYER 3 — UBUNTU BASE "Le Sol"
# ═══════════════════════════════════════════════════════════════════════════
install_layer3() {
    step "Installing Layer 3 — Ubuntu Base (Le Sol)..."

    info "Updating package lists..."
    apt-get update -qq

    info "Upgrading existing packages..."
    apt-get upgrade -y -qq

    info "Installing system essentials..."
    apt-get install -y -qq \
        build-essential \
        software-properties-common \
        apt-transport-https \
        ca-certificates \
        gnupg \
        lsb-release \
        curl \
        wget \
        htop \
        neofetch \
        tree \
        unzip \
        zip \
        p7zip-full \
        ntfs-3g \
        exfat-fuse \
        exfatprogs \
        gparted \
        ufw \
        net-tools \
        openssh-client \
        tmux \
        screen

    info "Installing XFCE desktop (lightweight)..."
    apt-get install -y -qq \
        xfce4 \
        xfce4-goodies \
        xfce4-terminal \
        thunar \
        ristretto \
        mousepad

    info "Setting up firewall..."
    ufw logging off
    ufw default deny incoming
    ufw default allow outgoing
    ufw allow ssh
    ufw --force enable || warn "Firewall warning — non-blocking, continuing..."

    info "Installing Timeshift (system snapshots)..."
    apt-get install -y -qq timeshift

    # Remove bloat
    info "Removing bloatware..."
    apt-get remove -y -qq \
        thunderbird \
        libreoffice-common \
        gnome-games \
        aisleriot \
        gnome-mines \
        gnome-sudoku \
        2>/dev/null || true

    apt-get autoremove -y -qq

    success "Layer 3 — Le Sol — installed"
}

# ═══════════════════════════════════════════════════════════════════════════
# LAYER 2 — INTERFACE "Le Pont"
# ═══════════════════════════════════════════════════════════════════════════
install_layer2() {
    step "Installing Layer 2 — Interface (Le Pont)..."

    # Python
    info "Installing Python 3.12..."
    add-apt-repository -y ppa:deadsnakes/ppa 2>/dev/null || true
    apt-get update -qq
    apt-get install -y -qq \
        python3.12 \
        python3.12-venv \
        python3-pip

    # Node.js 20
    info "Installing Node.js 20..."
    if ! command -v node &>/dev/null; then
        curl -fsSL https://deb.nodesource.com/setup_20.x | bash - 2>/dev/null
        apt-get install -y -qq nodejs
    fi

    # Java
    info "Installing Java 21..."
    apt-get install -y -qq openjdk-21-jdk

    # Rust
    info "Installing Rust..."
    if ! command -v rustc &>/dev/null; then
        sudo -u "$SUDO_USER" bash -c 'curl --proto "=https" --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y'
    fi

    # Git + GitHub CLI
    info "Installing Git & GitHub CLI..."
    apt-get install -y -qq git
    if ! command -v gh &>/dev/null; then
        curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | \
            gpg --dearmor -o /usr/share/keyrings/githubcli-archive-keyring.gpg
        echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | \
            tee /etc/apt/sources.list.d/github-cli.list > /dev/null
        apt-get update -qq
        apt-get install -y -qq gh
    fi

    # VS Code
    info "Installing VS Code..."
    if ! command -v code &>/dev/null; then
        wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > /tmp/packages.microsoft.gpg
        install -D -o root -g root -m 644 /tmp/packages.microsoft.gpg /etc/apt/keyrings/packages.microsoft.gpg
        echo "deb [arch=amd64,arm64,armhf signed-by=/etc/apt/keyrings/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main" | \
            tee /etc/apt/sources.list.d/vscode.list > /dev/null
        apt-get update -qq
        apt-get install -y -qq code
    fi

    # Dev tools
    info "Installing dev tools..."
    apt-get install -y -qq \
        vim \
        make \
        cmake \
        gcc \
        g++ \
        nginx \
        jq \
        httpie

    # Web tools
    info "Installing Flask..."
    sudo -u "$SUDO_USER" python3.12 -m pip install --user flask gunicorn 2>/dev/null || \
        pip3 install flask gunicorn

    # Firefox + uBlock Origin
    info "Installing Firefox..."
    apt-get install -y -qq firefox

    success "Layer 2 — Le Pont — installed"
}

# ═══════════════════════════════════════════════════════════════════════════
# LAYER 1 — AI "L'Architecte"
# ═══════════════════════════════════════════════════════════════════════════
install_layer1() {
    step "Installing Layer 1 — AI (L'Architecte)..."

    # Ollama
    info "Installing Ollama (local LLM server)..."
    if ! command -v ollama &>/dev/null; then
        curl -fsSL https://ollama.com/install.sh | sh
    fi

    # Detect RAM for model selection
    RAM_MB=$(free -m | awk '/Mem:/{print $2}')

    if [ "$RAM_MB" -ge 16000 ]; then
        AI_MODEL="llama3:8b"
        info "16GB+ RAM detected — will pull Llama 3 (8B)"
    elif [ "$RAM_MB" -ge 8000 ]; then
        AI_MODEL="phi3:mini"
        info "8GB+ RAM detected — will pull Phi-3 Mini (3.8B)"
    else
        AI_MODEL="tinyllama"
        info "<8GB RAM — will pull TinyLlama (1.1B)"
    fi

    info "Pulling AI model: $AI_MODEL (this may take a while)..."
    sudo -u "$SUDO_USER" ollama pull "$AI_MODEL" || warn "Model pull failed — run 'ollama pull $AI_MODEL' later"

    # Open WebUI
    info "Installing Open WebUI..."
    if command -v docker &>/dev/null; then
        docker pull ghcr.io/open-webui/open-webui:main 2>/dev/null || \
            warn "Docker pull failed — install Open WebUI manually"
    else
        info "Installing Docker for Open WebUI..."
        apt-get install -y -qq docker.io docker-compose
        systemctl enable docker
        systemctl start docker
        usermod -aG docker "$SUDO_USER"
        docker pull ghcr.io/open-webui/open-webui:main 2>/dev/null || \
            warn "Docker pull failed — run install again after reboot"
    fi

    # Python AI stack
    info "Creating AI virtual environment..."
    AIVENV="$AOS_HOME/ai-env"
    sudo -u "$SUDO_USER" python3.12 -m venv "$AIVENV"
    sudo -u "$SUDO_USER" "$AIVENV/bin/pip" install --upgrade pip
    sudo -u "$SUDO_USER" "$AIVENV/bin/pip" install \
        torch --index-url https://download.pytorch.org/whl/cpu \
        transformers \
        langchain \
        numpy \
        pandas \
        matplotlib \
        jupyterlab \
        2>/dev/null || warn "Some AI packages failed — run aos-ai setup later"

    success "Layer 1 — L'Architecte — installed"
}

# ═══════════════════════════════════════════════════════════════════════════
# JUXITT TOOLKIT
# ═══════════════════════════════════════════════════════════════════════════
install_toolkit() {
    step "Installing JuXITT Toolkit..."

    # Create AOS directory structure
    info "Creating AOS directory structure..."
    sudo -u "$SUDO_USER" mkdir -p "$AOS_HOME"/{bin,config,workspace/{projects,repos}}

    # ─── aos-status ───
    cat > "$AOS_HOME/bin/aos-status" << 'STATUSEOF'
#!/bin/bash
CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}"
echo "╔════════════════════════════════════════════════╗"
echo "║          LinuxAOS — System Status              ║"
echo "╠════════════════════════════════════════════════╣"

# Layer 1 — AI
if pgrep -x "ollama" > /dev/null; then
    echo -e "║  Layer 1 (AI):        ${GREEN}● Online${CYAN}                ║"
else
    echo -e "║  Layer 1 (AI):        ${RED}○ Offline${CYAN}               ║"
fi

# Layer 2 — Interface
echo -e "║  Layer 2 (Interface): ${GREEN}● Ready${CYAN}                 ║"

# Layer 3 — Ubuntu
echo -e "║  Layer 3 (Ubuntu):    ${GREEN}● Running${CYAN}               ║"

echo "╠════════════════════════════════════════════════╣"

# System info
RAM_USED=$(free -h | awk '/Mem:/{print $3}')
RAM_TOTAL=$(free -h | awk '/Mem:/{print $2}')
DISK_USED=$(df -h / | awk 'NR==2{print $3}')
DISK_TOTAL=$(df -h / | awk 'NR==2{print $2}')
CPU_LOAD=$(uptime | awk -F'load average:' '{print $2}' | cut -d',' -f1 | xargs)
UPTIME=$(uptime -p)

echo "║  RAM:    $RAM_USED / $RAM_TOTAL                          ║"
echo "║  Disk:   $DISK_USED / $DISK_TOTAL                          ║"
echo "║  CPU:    $CPU_LOAD                                  ║"
echo "║  Up:     $UPTIME          ║"
echo "╠════════════════════════════════════════════════╣"
echo "║  \"Try Me You'll Love Me!\"                      ║"
echo "║  JuXITT — The Meeting Point                    ║"
echo "╚════════════════════════════════════════════════╝"
echo -e "${NC}"
STATUSEOF

    # ─── aos-ai ───
    cat > "$AOS_HOME/bin/aos-ai" << 'AIEOF'
#!/bin/bash
case "$1" in
    start)
        echo "[AOS] Starting AI Layer..."
        systemctl start ollama 2>/dev/null || ollama serve &
        sleep 2
        if command -v docker &>/dev/null; then
            docker start open-webui 2>/dev/null || \
            docker run -d --name open-webui \
                -p 3000:8080 \
                --add-host=host.docker.internal:host-gateway \
                -v open-webui:/app/backend/data \
                --restart always \
                ghcr.io/open-webui/open-webui:main
        fi
        echo "[AOS] AI Layer online — Open WebUI at http://localhost:3000"
        ;;
    stop)
        echo "[AOS] Stopping AI Layer..."
        docker stop open-webui 2>/dev/null
        systemctl stop ollama 2>/dev/null || pkill ollama
        echo "[AOS] AI Layer offline"
        ;;
    status)
        if pgrep -x "ollama" > /dev/null; then
            echo "[AOS] Ollama: RUNNING"
            ollama list
        else
            echo "[AOS] Ollama: STOPPED"
        fi
        if docker ps 2>/dev/null | grep -q open-webui; then
            echo "[AOS] Open WebUI: RUNNING at http://localhost:3000"
        else
            echo "[AOS] Open WebUI: STOPPED"
        fi
        ;;
    chat)
        shift
        MODEL=${1:-$(ollama list 2>/dev/null | awk 'NR==2{print $1}')}
        echo "[AOS] Chat with $MODEL (Ctrl+D to exit)"
        ollama run "$MODEL"
        ;;
    models)
        ollama list
        ;;
    pull)
        ollama pull "$2"
        ;;
    *)
        echo "Usage: aos-ai {start|stop|status|chat|models|pull <model>}"
        ;;
esac
AIEOF

    # ─── aos-update ───
    cat > "$AOS_HOME/bin/aos-update" << 'UPDATEEOF'
#!/bin/bash
echo "[AOS] Updating LinuxAOS..."
echo "[AOS] Layer 3 — Ubuntu packages..."
sudo apt-get update -qq && sudo apt-get upgrade -y -qq
echo "[AOS] Layer 2 — Development tools..."
pip3 install --upgrade flask gunicorn 2>/dev/null
echo "[AOS] Layer 1 — AI models..."
ollama list 2>/dev/null | awk 'NR>1{print $1}' | while read model; do
    echo "  Updating $model..."
    ollama pull "$model"
done
echo "[AOS] All layers updated!"
UPDATEEOF

    # ─── aos-backup ───
    cat > "$AOS_HOME/bin/aos-backup" << 'BACKUPEOF'
#!/bin/bash
BACKUP_DIR="$HOME/aos-backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/aos-backup-$TIMESTAMP.tar.gz"
mkdir -p "$BACKUP_DIR"
echo "[AOS] Backing up configuration..."
tar -czf "$BACKUP_FILE" \
    "$HOME/aos/config" \
    "$HOME/.bashrc" \
    "$HOME/.gitconfig" \
    2>/dev/null
echo "[AOS] Backup saved: $BACKUP_FILE"
BACKUPEOF

    # Make all scripts executable
    chmod +x "$AOS_HOME/bin/"*

    # ─── Aliases ───
    info "Setting up aliases..."
    cat > "$AOS_HOME/config/aliases.sh" << 'ALIASEOF'
# ═══════════════════════════════════════════
# LinuxAOS — JuXITT Aliases
# ═══════════════════════════════════════════

# Navigation
alias ll='ls -lah --color=auto'
alias la='ls -A --color=auto'
alias ..='cd ..'
alias ...='cd ../..'

# Git shortcuts
alias gs='git status'
alias gp='git push'
alias gl='git log --oneline -20'
alias gc='git commit -m'
alias ga='git add'
alias gd='git diff'

# Python
alias py='python3.12'
alias venv='python3.12 -m venv'

# Dev
alias serve='python3 -m http.server 8080'
alias ports='netstat -tlnp'

# AOS commands
alias ai='aos-ai'
alias status='aos-status'
alias update='aos-update'
alias backup='aos-backup'

# Handy
alias cls='clear'
alias h='history | tail -30'
alias myip='curl -s ifconfig.me && echo'
ALIASEOF

    # ─── MOTD ───
    info "Setting up welcome message..."
    cat > "$AOS_HOME/config/motd" << 'MOTDEOF'

 ╔════════════════════════════════════════════════════════╗
 ║                                                        ║
 ║   LinuxAOS v0.1                                        ║
 ║   Adequate Operating System                            ║
 ║                                                        ║
 ║   "The AI does not need the machine.                   ║
 ║    The machine does not need the AI.                   ║
 ║    AOS is what happens when they choose to meet."      ║
 ║                                                        ║
 ║   The meeting point: JuXITT.                           ║
 ║                                                        ║
 ║   Type 'status' for system status                      ║
 ║   Type 'ai start' to launch AI Layer                   ║
 ║   Type 'ai chat' for terminal AI chat                  ║
 ║                                                        ║
 ║   "Try Me You'll Love Me!"                             ║
 ║                                                        ║
 ╚════════════════════════════════════════════════════════╝

MOTDEOF

    # ─── Integrate into .bashrc ───
    info "Integrating into shell..."
    BASHRC="/home/$SUDO_USER/.bashrc"

    if ! grep -q "LinuxAOS" "$BASHRC" 2>/dev/null; then
        cat >> "$BASHRC" << BASHEOF

# ═══════════════════════════════════════════
# LinuxAOS — Adequate Operating System
# ═══════════════════════════════════════════
export PATH="\$HOME/aos/bin:\$PATH"
source "\$HOME/aos/config/aliases.sh"
cat "\$HOME/aos/config/motd"
BASHEOF
    fi

    # Set ownership
    chown -R "$SUDO_USER:$SUDO_USER" "$AOS_HOME"

    success "JuXITT Toolkit installed"
}

# ═══════════════════════════════════════════════════════════════════════════
# DESKTOP BRANDING
# ═══════════════════════════════════════════════════════════════════════════
install_branding() {
    step "Applying AOS branding..."

    # ─── Wallpaper ───
    info "Installing AOS wallpaper..."
    WALLPAPER_DIR="/usr/share/backgrounds/aos"
    mkdir -p "$WALLPAPER_DIR"

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

    # Copy the real wallpaper PNG (generated with space + aurora + stars)
    if [ -f "$SCRIPT_DIR/aos-wallpaper.png" ]; then
        cp "$SCRIPT_DIR/aos-wallpaper.png" "$WALLPAPER_DIR/aos-wallpaper.png"
        success "Wallpaper installed"
    else
        warn "aos-wallpaper.png not found in $SCRIPT_DIR — using fallback"
        # Fallback: generate simple wallpaper with ImageMagick
        if command -v convert &>/dev/null; then
            convert -size 1920x1080 \
                -define gradient:angle=135 \
                gradient:'#0a0a2e'-'#1a1a4e' \
                -font Mono -pointsize 48 -fill '#4a9eff' \
                -gravity center -annotate +0-50 'LinuxAOS' \
                -pointsize 20 -fill '#6ab0ff' \
                -annotate +0+10 'Adequate Operating System' \
                -pointsize 16 -fill '#8ac4ff' \
                -annotate +0+50 '"Try Me You'\''ll Love Me!"' \
                "$WALLPAPER_DIR/aos-wallpaper.png" 2>/dev/null || true
        fi
    fi

    # Set XFCE wallpaper for all monitors
    info "Setting XFCE wallpaper..."
    sudo -u "$SUDO_USER" bash -c '
        for prop in $(xfconf-query -c xfce4-desktop -l 2>/dev/null | grep last-image); do
            xfconf-query -c xfce4-desktop -p "$prop" -s "/usr/share/backgrounds/aos/aos-wallpaper.png" 2>/dev/null
        done
    ' || true

    # ─── Plymouth Boot Splash ───
    info "Installing Plymouth boot theme..."
    PLYMOUTH_DIR="/usr/share/plymouth/themes/aos-theme"
    mkdir -p "$PLYMOUTH_DIR"

    if [ -d "$SCRIPT_DIR/plymouth/aos-theme" ]; then
        cp "$SCRIPT_DIR/plymouth/aos-theme/"* "$PLYMOUTH_DIR/" 2>/dev/null
        # Set as default boot theme
        if command -v plymouth-set-default-theme &>/dev/null; then
            plymouth-set-default-theme aos-theme 2>/dev/null || true
            update-initramfs -u 2>/dev/null || true
        fi
        success "Plymouth boot theme installed"
    else
        warn "Plymouth theme not found — skipping boot splash"
    fi

    # ─── GRUB Theme ───
    info "Installing GRUB theme..."
    GRUB_THEME_DIR="/boot/grub/themes/aos-theme"
    mkdir -p "$GRUB_THEME_DIR"

    if [ -d "$SCRIPT_DIR/grub/aos-theme" ]; then
        cp "$SCRIPT_DIR/grub/aos-theme/"* "$GRUB_THEME_DIR/" 2>/dev/null
        # Enable GRUB theme
        if ! grep -q "GRUB_THEME=" /etc/default/grub 2>/dev/null; then
            echo "GRUB_THEME=\"$GRUB_THEME_DIR/theme.txt\"" >> /etc/default/grub
        else
            sed -i "s|^GRUB_THEME=.*|GRUB_THEME=\"$GRUB_THEME_DIR/theme.txt\"|" /etc/default/grub
        fi
        update-grub 2>/dev/null || true
        success "GRUB theme installed"
    else
        warn "GRUB theme not found — skipping"
    fi

    # ─── Terminal Theme ───
    info "Customizing terminal colors..."
    TERM_DIR="/home/$SUDO_USER/.config/xfce4/terminal"
    sudo -u "$SUDO_USER" mkdir -p "$TERM_DIR"
    cat > "$TERM_DIR/terminalrc" << 'TERMEOF'
[Configuration]
BackgroundMode=TERMINAL_BACKGROUND_TRANSPARENT
BackgroundDarkness=0.90
ColorForeground=#c0c5ce
ColorBackground=#0a0a1a
ColorCursor=#c0c5ce
ColorPalette=#2b303b;#bf616a;#a3be8c;#ebcb8b;#4a9eff;#b48ead;#96b5b4;#c0c5ce;#65737e;#bf616a;#a3be8c;#ebcb8b;#8fa1b3;#b48ead;#96b5b4;#eff1f5
FontName=Monospace 11
MiscAlwaysShowTabs=FALSE
MiscBordersDefault=TRUE
MiscConfirmClose=TRUE
MiscDefaultGeometry=120x35
ScrollingBar=TERMINAL_SCROLLBAR_NONE
TERMEOF
    chown -R "$SUDO_USER:$SUDO_USER" "$TERM_DIR"

    success "AOS branding applied — wallpaper + boot + GRUB + terminal"
}

# ═══════════════════════════════════════════════════════════════════════════
# BOOKMARKS
# ═══════════════════════════════════════════════════════════════════════════
install_bookmarks() {
    step "Setting up browser bookmarks..."

    BOOKMARK_DIR="/home/$SUDO_USER/.mozilla/firefox"
    info "Firefox bookmarks will include:"
    info "  • juxitt.com"
    info "  • github.com/alissali"
    info "  • localhost:3000 (Open WebUI)"
    info "  → Configure manually on first launch"

    success "Bookmarks noted"
}

# ═══════════════════════════════════════════════════════════════════════════
# FINAL SUMMARY
# ═══════════════════════════════════════════════════════════════════════════
final_summary() {
    RAM_MB=$(free -m | awk '/Mem:/{print $2}')

    echo -e "\n${CYAN}"
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║                                                            ║"
    echo "║   ✓ LinuxAOS v${AOS_VERSION} — Installation Complete!             ║"
    echo "║                                                            ║"
    echo "║   Layer 3 (Ubuntu):    ✓ Installed & hardened              ║"
    echo "║   Layer 2 (Interface): ✓ Dev tools ready                   ║"
    echo "║   Layer 1 (AI):        ✓ Ollama + Open WebUI              ║"
    echo "║   JuXITT Toolkit:      ✓ Commands & aliases active        ║"
    echo "║   Branding:            ✓ Desktop customized                ║"
    echo "║                                                            ║"
    echo "║   Quick commands:                                          ║"
    echo "║     status     → System status                             ║"
    echo "║     ai start   → Launch AI Layer                           ║"
    echo "║     ai chat    → Terminal AI chat                          ║"
    echo "║     update     → Update all layers                         ║"
    echo "║     backup     → Backup configuration                     ║"
    echo "║                                                            ║"
    echo "║   \"Try Me You'll Love Me!\"                                 ║"
    echo "║                                                            ║"
    echo "║   Please reboot to complete installation:                  ║"
    echo "║   $ sudo reboot                                            ║"
    echo "║                                                            ║"
    echo "║   © Mamoun Alissali — JuXITT — The Meeting Point          ║"
    echo "║                                                            ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════
main() {
    banner
    preflight

    echo -e "\n${BOLD}LinuxAOS will now install 3 layers on this machine.${NC}"
    echo "This will take 15-45 minutes depending on your connection."
    read -p "Continue? (y/n) " -n 1 -r
    echo
    [[ ! $REPLY =~ ^[Yy]$ ]] && exit 0

    install_layer3
    install_layer2
    install_layer1
    install_toolkit
    install_branding
    install_bookmarks
    final_summary
}

main "$@"
