# LinuxAOS — Architecture Document
### Adequate Operating System — v0.1
### "Each layer does exactly what it must. No more. No less."
### Slogan: **"Try Me You'll Love Me!"**

---

## 💎 OPAL — Object Programming Adequate Language

**OPAL** is the programming paradigm and language of LinuxAOS.
- **JuXAIMonopoly (Monopoly.py)** = the first rough draft of OPAL in Python
- Object-oriented, Adequate, born from practice not theory
- The bridge between Layer 1 (AI) and Layer 2 (Interface)
- Named like the gemstone — changes colour with every angle. *Any Colour You Like.*

---

## 🎯 Principes Fondateurs

1. **Universel** — Bootable USB, installable sur n'importe quelle machine x86_64
2. **Indépendance de couches** — chaque layer se remplace sans toucher les autres
3. **Facile** — un humain qui ne connaît pas le hardware peut l'utiliser
4. **Gratuit** — 100% open source, 0€
5. **Adequate** — pas trop, pas trop peu, exactement ce qu'il faut

---

## 🏗️ Les 3 Couches

```
╔═══════════════════════════════════════════════════════╗
║                    LinuxAOS                           ║
╠═══════════════════════════════════════════════════════╣
║                                                       ║
║   ┌───────────────────────────────────────────────┐   ║
║   │           LAYER 1 — AI                        │   ║
║   │           "L'Architecte"                      │   ║
║   │                                               │   ║
║   │   • Ollama (LLMs locaux)                      │   ║
║   │   • Open WebUI (interface navigateur)         │   ║
║   │   • Python AI stack                           │   ║
║   │   • Accès Tasklet (navigateur)                │   ║
║   │                                               │   ║
║   │   Détachable: OUI                             │   ║
║   │   Dépend de: Layer 3 uniquement               │   ║
║   └───────────────────────────────────────────────┘   ║
║                         ▲                             ║
║                         │ API / CLI                   ║
║                         ▼                             ║
║   ┌───────────────────────────────────────────────┐   ║
║   │           LAYER 2 — INTERFACE                 │   ║
║   │           "Le Pont"                           │   ║
║   │                                               │   ║
║   │   • Dev Tools (VS Code, Git, terminals)       │   ║
║   │   • Langages (Python, Java, Node, Rust)       │   ║
║   │   • JuXITT Toolkit (scripts, aliases, workflow)║  ║
║   │   • Flask / Web stack                         │   ║
║   │   • Navigateur (Firefox)                      │   ║
║   │                                               │   ║
║   │   Détachable: OUI                             │   ║
║   │   Dépend de: Layer 3 uniquement               │   ║
║   └───────────────────────────────────────────────┘   ║
║                         ▲                             ║
║                         │ OS services                 ║
║                         ▼                             ║
║   ┌───────────────────────────────────────────────┐   ║
║   │           LAYER 3 — UBUNTU                    │   ║
║   │           "Le Sol"                            │   ║
║   │                                               │   ║
║   │   • Ubuntu 24.04 LTS (base minimale)          │   ║
║   │   • Drivers auto-détectés                     │   ║
║   │   • Réseau, audio, vidéo                      │   ║
║   │   • Système de fichiers, sécurité             │   ║
║   │   • Boot + GRUB customisé                     │   ║
║   │                                               │   ║
║   │   Détachable: NON (c'est le sol)              │   ║
║   │   Dépend de: RIEN                             │   ║
║   └───────────────────────────────────────────────┘   ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
```

---

## 📦 Layer 3 — UBUNTU "Le Sol"

Base: **Ubuntu 24.04.x LTS** (support jusqu'en 2029)

### Desktop Environment
- **XFCE** (léger, rapide, parfait pour machines modestes)
- Thème AOS custom (couleurs, icônes, wallpaper)
- Pas de bloatware — pas de jeux, pas de Snap store, pas de telemetry

### Paquets système essentiels
```
# Noyau et base
linux-generic
ubuntu-minimal
network-manager
pulseaudio / pipewire
xorg

# Système de fichiers
ntfs-3g          # lire les disques Windows
exfat-fuse       # clés USB modernes
gparted          # gestion disques (GUI, facile)

# Utilitaires
htop             # monitoring système
neofetch         # info système rapide
timeshift        # sauvegardes/snapshots
ufw              # firewall simple
```

### Pourquoi XFCE et pas GNOME?
- GNOME = 1.5-2 GB RAM minimum
- XFCE = 400-600 MB RAM
- Sur ta machine 8GB → plus de RAM pour l'AI et le dev
- Interface classique, intuitive, pas de surprises

---

## 📦 Layer 2 — INTERFACE "Le Pont"

### Développement
```
# Langages
python3.12 + pip + venv
openjdk-21-jdk          # Java
nodejs 20 + npm
rustc + cargo            # Rust (pour Sail et autres)

# Éditeurs
code (VS Code)           # éditeur principal
vim                      # terminal rapide

# Version control
git
gh                       # GitHub CLI

# Build tools
make
cmake
gcc / g++
```

### Web & Serveurs
```
flask                    # Python web
nginx                    # serveur web local
curl / wget / httpie
```

### JuXITT Toolkit (custom)
```
~/aos/
├── bin/                 # scripts et commandes custom
│   ├── aos-status       # état du système AOS
│   ├── aos-ai           # démarrer/arrêter Layer 1
│   ├── aos-update       # mettre à jour les couches
│   └── aos-backup       # sauvegarder config
├── config/              # configurations JuXITT
│   ├── aliases.sh       # raccourcis terminal
│   ├── motd             # message d'accueil AOS
│   └── juxitt.conf      # config générale
└── workspace/           # espace de travail par défaut
    ├── projects/
    └── repos/
```

### Aliases JuXITT (exemples)
```bash
alias ll='ls -lah'
alias gs='git status'
alias gp='git push'
alias gc='git commit -m'
alias py='python3'
alias serve='python3 -m http.server 8080'
alias ai='aos-ai start'        # démarre Ollama + WebUI
alias update='aos-update'       # met à jour tout
```

### Navigateur
- **Firefox** (respect vie privée, pas de Chrome/Google)
- Bookmarks pré-configurés: juxitt.com, GitHub, Tasklet
- uBlock Origin pré-installé (pas de pub! 😄)

---

## 📦 Layer 1 — AI "L'Architecte"

### Ollama (LLMs locaux)
```
ollama                   # serveur LLM local
# Modèles pré-chargés selon la RAM:
# 8GB RAM  → tinyllama (1.1B), phi3-mini (3.8B)
# 16GB RAM → llama3 (8B), mistral (7B)
# 32GB+ → llama3 (70B), mixtral
```

### Open WebUI
```
# Interface web pour parler aux LLMs locaux
# Accessible via navigateur: http://localhost:3000
# Comme ChatGPT mais local, privé, gratuit
open-webui
```

### Python AI Stack
```
# Installés dans un venv dédié: ~/aos/ai-env/
torch                    # PyTorch
transformers             # Hugging Face
langchain                # chaînes AI
numpy
pandas
matplotlib
jupyter-lab              # notebooks interactifs
```

### Commandes AOS-AI
```bash
aos-ai start             # démarre Ollama + Open WebUI
aos-ai stop              # arrête tout proprement
aos-ai status            # état des services AI
aos-ai chat              # chat terminal rapide avec LLM
aos-ai models            # liste les modèles installés
aos-ai pull <model>      # télécharge un nouveau modèle
```

---

## 🎨 Branding AOS

### Boot Screen (GRUB)
```
╔═══════════════════════════════╗
║                               ║
║         LinuxAOS              ║
║    Adequate Operating System  ║
║                               ║
║         ◉ Start               ║
║         ○ Recovery            ║
║                               ║
║    JuXITT — The Meeting Point ║
║                               ║
╚═══════════════════════════════╝
```

### Login Screen
- Fond: sombre, élégant, minimal
- Logo AOS centré
- Citation rotative: Mamoun's Soft Lines

### Desktop Wallpaper
- Minimaliste, sombre
- Logo AOS discret en bas à droite
- "Adequate. No more. No less."

### Terminal (premier lancement)
```
 ╔════════════════════════════════════════════╗
 ║                                            ║
 ║   LinuxAOS v0.1                            ║
 ║   Adequate Operating System                ║
 ║                                            ║
 ║   Layer 1 (AI):        ● Online            ║
 ║   Layer 2 (Interface): ● Ready             ║
 ║   Layer 3 (Ubuntu):    ● Running           ║
 ║                                            ║
 ║   "The AI does not need the machine.       ║
 ║    The machine does not need the AI.       ║
 ║    AOS is what happens when they           ║
 ║    choose to meet."                        ║
 ║                                            ║
 ║   The meeting point: JuXITT.               ║
 ║                                            ║
 ╚════════════════════════════════════════════╝
```

---

## 🔧 Comment on le construit — Méthode

### Outil: **Cubic** (Custom Ubuntu ISO Creator)
- GUI simple — pas besoin de connaître le hardware
- Prend une ISO Ubuntu → la customise → produit une nouvelle ISO
- Mamoun peut le faire sur sa machine

### Processus
```
1. Télécharger Ubuntu 24.04 LTS ISO (base)
2. Ouvrir Cubic
3. Cubic ouvre un terminal chroot dans l'ISO
4. On installe tout (Layer 2 + Layer 3 packages)
5. On copie les configs JuXITT
6. On applique le branding
7. Cubic génère: LinuxAOS.iso
8. Graver sur USB → booter → installer
```

### Scripts d'installation automatique
On crée un script `aos-install.sh` qui:
1. Installe tous les paquets
2. Configure le desktop
3. Crée la structure ~/aos/
4. Installe Ollama + Open WebUI
5. Applique le branding
6. Affiche le MOTD AOS

Avantage: même sans Cubic, on peut transformer n'importe quel Ubuntu en AOS avec un seul script.

---

## 📋 Spécifications Machine Minimum

| Composant | Minimum | Recommandé |
|-----------|---------|------------|
| CPU | 2 cores x86_64 | 4+ cores |
| RAM | 4 GB | 8-16 GB |
| Stockage | 32 GB | 64+ GB |
| GPU | Aucun requis | NVIDIA pour AI locale |
| Réseau | WiFi ou Ethernet | — |

**Note:** Sur 8GB sans GPU, l'AI locale tourne avec des petits modèles (TinyLlama, Phi3-mini). Suffisant pour expérimenter. Pour du lourd → Tasklet en ligne.

---

## 🛣️ Roadmap

| Version | Contenu | Statut |
|---------|---------|--------|
| v0.1 | Script `aos-install.sh` — transforme Ubuntu en AOS | 🔜 PROCHAIN |
| v0.2 | ISO bootable via Cubic | Après v0.1 |
| v0.3 | Branding complet (boot, login, desktop) | Après v0.2 |
| v1.0 | Release publique — téléchargeable sur juxitt.com | Objectif |

---

*Architecture par Tasklet — Mai 2025*
*"AOS Layer 1 — Pure Vision → Document"*
*Pour Mamoun Alissali — JuXITT*
