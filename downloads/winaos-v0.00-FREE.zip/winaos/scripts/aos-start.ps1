# AOS Start — Launch all services — WinAOS v0.00
$AOS = "$env:USERPROFILE\AOS"
Write-Host "☕ Starting WinAOS services..." -ForegroundColor Green

$ollama = "$AOS\bin\ollama\ollama.exe"
if (Test-Path $ollama) {
    Start-Process $ollama "serve" -WindowStyle Hidden
    Write-Host "  🤖 Ollama started" -ForegroundColor Cyan
} else {
    Write-Host "  ⚠️ Ollama not found — run aos-install-ai" -ForegroundColor Yellow
}

$py = "$AOS\bin\python\python.exe"
$mm = "$AOS\apps\mMonopoly\app.py"
if ((Test-Path $py) -and (Test-Path $mm)) {
    Start-Process $py $mm -WorkingDirectory "$AOS\apps\mMonopoly" -WindowStyle Hidden
    Write-Host "  🎯 mMonopoly → http://localhost:8080" -ForegroundColor Cyan
}

Start-Sleep 3
Write-Host "☕ Done! Type 'aos-status' to check." -ForegroundColor Green
