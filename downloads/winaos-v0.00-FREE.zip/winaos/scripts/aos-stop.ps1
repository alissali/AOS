# AOS Stop — WinAOS v0.00
Write-Host "⏹ Stopping WinAOS services..." -ForegroundColor Yellow
foreach ($name in @("ollama", "python")) {
    $procs = Get-Process -Name $name -ErrorAction SilentlyContinue
    if ($procs) {
        $procs | Stop-Process -Force
        Write-Host "  ⏹ $name stopped" -ForegroundColor DarkGray
    }
}
Write-Host "☕ All services stopped." -ForegroundColor Yellow
