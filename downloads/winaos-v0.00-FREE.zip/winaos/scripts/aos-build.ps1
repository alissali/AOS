# ═══════════════════════════════════════════════
# WinAOS Build Script — For Wonder 🤖
# Run on Windows to prepare the full installer
# ═══════════════════════════════════════════════

$BUILD = "$PSScriptRoot\..\build"
$DIST = "$PSScriptRoot\..\installer\dist"

Write-Host "🏗️ Building WinAOS v0.00..." -ForegroundColor Green

# Create directory structure
$dirs = @(
    "bin\python", "bin\node", "bin\git", "bin\ollama",
    "apps\JuXAIMonopoly", "apps\mMonopoly", "apps\OpenWebUI",
    "config", "scripts", "wallpaper", "models"
)
foreach ($d in $dirs) {
    New-Item -ItemType Directory -Force -Path "$DIST\$d" | Out-Null
}
New-Item -ItemType Directory -Force -Path $BUILD | Out-Null
Write-Host "📁 Directory structure created" -ForegroundColor Cyan

# Step 1: Python Embeddable
Write-Host "🐍 Downloading Python 3.12 embeddable..." -ForegroundColor Cyan
$pyUrl = "https://www.python.org/ftp/python/3.12.4/python-3.12.4-embed-amd64.zip"
Invoke-WebRequest -Uri $pyUrl -OutFile "$BUILD\python-embed.zip"
Expand-Archive -Path "$BUILD\python-embed.zip" -DestinationPath "$DIST\bin\python" -Force
Write-Host "  ✅ Python 3.12 ready" -ForegroundColor Green

# Step 2: Node.js Portable
Write-Host "📦 Downloading Node.js 20..." -ForegroundColor Cyan
$nodeUrl = "https://nodejs.org/dist/v20.15.0/node-v20.15.0-win-x64.zip"
Invoke-WebRequest -Uri $nodeUrl -OutFile "$BUILD\node.zip"
Expand-Archive -Path "$BUILD\node.zip" -DestinationPath "$BUILD\node-tmp" -Force
Move-Item "$BUILD\node-tmp\node-*\*" "$DIST\bin\node\" -Force
Write-Host "  ✅ Node.js 20 ready" -ForegroundColor Green

# Step 3: Git Portable
Write-Host "📦 Git Portable..." -ForegroundColor Yellow
Write-Host "  ⚠️ Download manually: https://git-scm.com/download/win" -ForegroundColor Yellow
Write-Host "  Extract to: $DIST\bin\git" -ForegroundColor Yellow

# Step 4: Clone AOS apps from GitHub
Write-Host "🎲 Cloning AOS apps..." -ForegroundColor Cyan
git clone https://github.com/alissali/AOS.git "$BUILD\AOS-repo" 2>$null
if (Test-Path "$BUILD\AOS-repo") {
    Copy-Item "$BUILD\AOS-repo\*" "$DIST\apps\" -Recurse -Force
    Write-Host "  ✅ AOS apps cloned" -ForegroundColor Green
}

# Step 5: Copy local configs, scripts, wallpaper
Write-Host "⚙️ Copying configs and scripts..." -ForegroundColor Cyan
Copy-Item "$PSScriptRoot\..\config\*" "$DIST\config\" -Recurse -Force
Copy-Item "$PSScriptRoot\..\scripts\aos-start.ps1" "$DIST\scripts\" -Force
Copy-Item "$PSScriptRoot\..\scripts\aos-stop.ps1" "$DIST\scripts\" -Force
Copy-Item "$PSScriptRoot\..\scripts\aos-update.ps1" "$DIST\scripts\" -Force
Copy-Item "$PSScriptRoot\..\wallpaper\*" "$DIST\wallpaper\" -Force -ErrorAction SilentlyContinue
Write-Host "  ✅ Assets copied" -ForegroundColor Green

# Final instructions
Write-Host ""
Write-Host "═══════════════════════════════════════════" -ForegroundColor Green
Write-Host "  🏗️ BUILD FILES READY!" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "  Next steps:" -ForegroundColor Cyan
Write-Host "  1. pip install pyinstaller" -ForegroundColor White
Write-Host "  2. pyinstaller --onefile --windowed --icon=aos.ico launcher\aos_launcher.py" -ForegroundColor White
Write-Host "  3. Copy dist\aos_launcher.exe → installer\dist\AOS.exe" -ForegroundColor White
Write-Host "  4. Install Inno Setup: https://jrsoftware.org/isdl.php" -ForegroundColor White
Write-Host "  5. Open and compile: installer\WinAOS-Setup.iss" -ForegroundColor White
Write-Host "  → Output: WinAOS-v0.00-FREE-Setup.exe 🎉" -ForegroundColor Yellow
Write-Host ""
Write-Host "🐻 + 🤖 = Coherence INSIDE Harmony ☕🟩⬜⬛" -ForegroundColor DarkGray
