# AOS Update — Self-update from GitHub — WinAOS v0.00
$AOS = "$env:USERPROFILE\AOS"
Write-Host "🔄 Checking for WinAOS updates..." -ForegroundColor Cyan

$git = "$AOS\bin\git\cmd\git.exe"
if (Test-Path $git) {
    Push-Location $AOS
    & $git pull origin main
    Pop-Location
    Write-Host "✅ WinAOS updated!" -ForegroundColor Green
} else {
    Write-Host "⚠️ Git not found. Download update from: https://github.com/alissali/AOS" -ForegroundColor Yellow
}
