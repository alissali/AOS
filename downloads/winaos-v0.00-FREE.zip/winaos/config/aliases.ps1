# SpiceCoffee AOS — PowerShell Profile — WinAOS v0.00
$AOS_ROOT = "$env:USERPROFILE\AOS"
$env:AOS_HOME = $AOS_ROOT
$env:PATH = "$AOS_ROOT\bin\python;$AOS_ROOT\bin\node;$AOS_ROOT\bin\git\cmd;$AOS_ROOT\bin\ollama;$env:PATH"

function prompt {
    $loc = (Get-Location).Path.Replace($env:USERPROFILE, "~")
    Write-Host "☕ " -NoNewline -ForegroundColor DarkYellow
    Write-Host "AOS" -NoNewline -ForegroundColor Green
    Write-Host " $loc" -NoNewline -ForegroundColor Cyan
    Write-Host " >" -NoNewline -ForegroundColor Green
    return " "
}

function aos-start { & "$AOS_ROOT\scripts\aos-start.ps1" }
function aos-stop { & "$AOS_ROOT\scripts\aos-stop.ps1" }
function aos-status {
    Write-Host "`n  ☕ WinAOS Status" -ForegroundColor Green
    Write-Host "  AOS Home: $AOS_ROOT" -ForegroundColor Cyan
    foreach ($p in @("python","ollama","node")) {
        $r = Get-Process -Name $p -ErrorAction SilentlyContinue
        if ($r) { Write-Host "  $p : ✅ Running" -ForegroundColor Green }
        else { Write-Host "  $p : ⏹ Stopped" -ForegroundColor DarkGray }
    }
}
function jux { Start-Process "https://juxitt.com" }

Write-Host "`n  ╔══════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║     ☕ WinAOS v0.00 — SpiceCoffee    ║" -ForegroundColor Green
Write-Host "  ║   Try Me You'll Love Me!   🦅        ║" -ForegroundColor Yellow
Write-Host "  ╚══════════════════════════════════════╝" -ForegroundColor Green
Write-Host "  Commands: aos-status | aos-start | aos-stop | jux" -ForegroundColor Cyan
Write-Host "  🐻 + 🤖 = Coherence INSIDE Harmony ☕🟩⬜⬛`n" -ForegroundColor DarkGray
