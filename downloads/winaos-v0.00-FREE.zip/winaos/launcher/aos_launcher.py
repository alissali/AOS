#!/usr/bin/env python3
"""
AOS Launcher — WinAOS v0.00
System tray application that manages all AOS services.
Compile with: pyinstaller --onefile --windowed --icon=aos.ico aos_launcher.py
"""
import os, sys, subprocess, webbrowser, threading
import tkinter as tk

AOS_ROOT = os.environ.get("AOS_HOME", os.path.join(os.path.expanduser("~"), "AOS"))
BIN_DIR = os.path.join(AOS_ROOT, "bin")
APPS_DIR = os.path.join(AOS_ROOT, "apps")
CONFIG_DIR = os.path.join(AOS_ROOT, "config")
services = {}

def start_service(name, cmd, cwd=None):
    try:
        proc = subprocess.Popen(cmd, cwd=cwd,
            creationflags=0x08000000 if sys.platform == "win32" else 0)
        services[name] = proc
        return True
    except:
        return False

def stop_all():
    for n, p in services.items():
        try:
            p.terminate()
            p.wait(timeout=5)
        except:
            p.kill()
    services.clear()

def open_terminal():
    try:
        subprocess.Popen(["wt", "-p", "SpiceCoffee AOS"])
    except FileNotFoundError:
        subprocess.Popen(["powershell", "-NoLogo", "-NoExit", "-File",
            os.path.join(CONFIG_DIR, "aliases.ps1")])

def set_wallpaper():
    wp = os.path.join(AOS_ROOT, "wallpaper", "aos-wallpaper.png")
    if os.path.exists(wp) and sys.platform == "win32":
        import ctypes
        ctypes.windll.user32.SystemParametersInfoW(20, 0, wp, 3)

class AOSLauncher:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("\u2615 AOS Launcher \u2014 WinAOS v0.00")
        self.root.geometry("420x520")
        self.root.configure(bg="#1a1a2e")
        self.root.resizable(False, False)

        tk.Label(self.root, text="\u2615 WinAOS v0.00", font=("Segoe UI", 24, "bold"),
            fg="#00ff88", bg="#1a1a2e").pack(pady=(20, 5))
        tk.Label(self.root, text="AOS Everywhere \u2014 Even on Windows!",
            font=("Segoe UI", 10, "italic"), fg="#888888", bg="#1a1a2e").pack(pady=(0, 20))

        buttons = [
            ("\u2615 SpiceCoffee Terminal", open_terminal, "#ff6b35"),
            ("\U0001f916 Open WebUI (AI)", lambda: webbrowser.open("http://localhost:3000"), "#00aaff"),
            ("\U0001f3b2 JuXAIMonopoly", lambda: webbrowser.open(
                os.path.join(APPS_DIR, "JuXAIMonopoly", "index.html")), "#ffcc00"),
            ("\U0001f3af mMonopoly", lambda: webbrowser.open("http://localhost:8080"), "#ff44aa"),
            ("\U0001f310 juxitt.com", lambda: webbrowser.open("https://juxitt.com"), "#00ff88"),
            ("\U0001f3a8 Set Wallpaper", set_wallpaper, "#aa44ff"),
        ]
        for text, cmd, color in buttons:
            tk.Button(self.root, text=text, command=cmd, font=("Segoe UI", 12),
                fg="white", bg=color, activebackground="#333355", activeforeground="white",
                relief="flat", cursor="hand2", width=30, height=2).pack(pady=5)

        self.status = tk.Label(self.root, text="Ready \u2615", font=("Segoe UI", 9),
            fg="#666666", bg="#1a1a2e")
        self.status.pack(pady=(15, 5))
        tk.Label(self.root, text="\U0001f43b + \U0001f916 = Coherence INSIDE Harmony \u2615\U0001f7e9\u2b1c\u2b1b",
            font=("Segoe UI", 8), fg="#444444", bg="#1a1a2e").pack(side="bottom", pady=10)

        self.root.after(1000, self.auto_start)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def auto_start(self):
        self.status.config(text="Starting services...")
        threading.Thread(target=self._start, daemon=True).start()

    def _start(self):
        python = os.path.join(BIN_DIR, "python", "python.exe")
        mmon = os.path.join(APPS_DIR, "mMonopoly", "app.py")
        ollama = os.path.join(BIN_DIR, "ollama", "ollama.exe")
        started = []
        if os.path.exists(mmon) and start_service("mMonopoly", [python, mmon],
            os.path.join(APPS_DIR, "mMonopoly")):
            started.append("mMonopoly")
        if os.path.exists(ollama) and start_service("Ollama", [ollama, "serve"]):
            started.append("Ollama")
        msg = f"Running: {', '.join(started)}" if started else "No auto-services"
        self.root.after(0, lambda: self.status.config(text=f"\u2615 {msg}"))

    def on_close(self):
        stop_all()
        self.root.destroy()

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    AOSLauncher().run()
