; ═══════════════════════════════════════════════
; WinAOS Installer — Inno Setup Script
; v0.00 FREE
; Compile with: Inno Setup Compiler (iscc.exe)
; Download: https://jrsoftware.org/isdl.php
; ═══════════════════════════════════════════════

[Setup]
AppName=WinAOS
AppVersion=0.00
AppVerName=WinAOS v0.00 FREE
AppPublisher=JuXITT — Ma'moun Alissali
AppPublisherURL=https://juxitt.com
AppSupportURL=https://juxitt.com
DefaultDirName={userappdata}\AOS
DefaultGroupName=WinAOS
OutputBaseFilename=WinAOS-v0.00-FREE-Setup
Compression=lzma2/ultra64
SolidCompression=yes
PrivilegesRequired=lowest
DisableProgramGroupPage=yes
WizardStyle=modern

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "french"; MessagesFile: "compiler:Languages\French.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional:"; Flags: checked
Name: "wallpaper"; Description: "Set AOS wallpaper as desktop background"; GroupDescription: "Personalization:"
Name: "terminalprofile"; Description: "Add SpiceCoffee profile to Windows Terminal"; GroupDescription: "Personalization:"; Flags: checked

[Files]
Source: "dist\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\WinAOS"; Filename: "{app}\AOS.exe"
Name: "{group}\SpiceCoffee Terminal"; Filename: "powershell.exe"; Parameters: "-NoLogo -NoExit -File ""{app}\config\aliases.ps1"""
Name: "{group}\Uninstall WinAOS"; Filename: "{uninstallexe}"
Name: "{autodesktop}\WinAOS ☕"; Filename: "{app}\AOS.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\AOS.exe"; Description: "Launch WinAOS ☕"; Flags: nowait postinstall skipifsilent

[Code]
procedure SetWallpaper;
var
  WallpaperPath: String;
begin
  WallpaperPath := ExpandConstant('{app}\wallpaper\aos-wallpaper.png');
  if FileExists(WallpaperPath) then
  begin
    RegWriteStringValue(HKCU, 'Control Panel\Desktop', 'Wallpaper', WallpaperPath);
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
  begin
    if IsTaskSelected('wallpaper') then
      SetWallpaper;
  end;
end;

[UninstallDelete]
Type: filesandordirs; Name: "{app}"
